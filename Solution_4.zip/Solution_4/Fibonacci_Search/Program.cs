﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fibonacci_Search
{
    //DONE
    internal class Program
    {     
        //Function gives Fibonacci number
        public static int Fibo(int n)
        {
            int f0 = 1;
            int f1 = 1;
            if (n == 0)
            {
                return f0;
            }
            if (n == 1)
            {
                return f1;
            }
            for (int i = 2; i <= n; i++)
            {
                int tmp = f1;
                f1 += f0;
                f0 = tmp;
            }
            return f1;
            
        }
        public static double Fibonacci(double a, double b, double EPS)
        {     
            
            double c = (b - a) / EPS;
            int n = 1;
            double x1, x2, f1, f2;

            n+=1;
           
            while(Fibo(n) < c)
            {
                n += 1;
            }
                                
            x1 = a + ((double)Fibo(n - 2) / Fibo(n)) * (b - a);
            x2 = a + ((double)Fibo(n - 1) / Fibo(n)) * (b - a);
            f1 = Function(x1);
            f2 = Function(x2);

            for ( int k = 1; k < n - 2; k++)
            {
                if (Function(x1) < Function(x2))
                {
                    b = x2;
                    x2 = x1;
                    f2 = f1;
                    x1 = a + ((double)Fibo(n - k - 2) / Fibo(n - k)) * (b - a);

                }
                else
                {
                    a = x1;
                    x1 = x2;
                    f1 = f2;
                    x2 = a + ((double)Fibo(n - k - 1) / Fibo(n - k)) * (b - a);
                }
            }

            if (Function(x1) < Function(x2))
            {
                b = x2;
                x2 = x1;
                f2 = f1;
            }
            else
            {
                a = x1;
            }
            x1 = x2 - EPS * (b - a);           
            if (Function(x1) < Function(x2))
            {
                return 0.5 * (a + x1);
            }
            else if (Function(x1) == Function(x2))
            {
                return 0.5 * (x1 + x2);
            }
            else
            {
                return 0.5 * (x1 + b);
            }

        }
        public static double Function(double x)
        {
            return x * x * x * x + 2 * x + 1;
        }
        
        static void Main(string[] args)
        {
            //Fibonacci test

            //Console.WriteLine(PushFib(0));
            //Console.WriteLine(PushFib(1));
            //Console.WriteLine(PushFib(2));
            //Console.WriteLine(PushFib(3));
            //Console.WriteLine(PushFib(4));

            //FibonacciSearch test
            Console.WriteLine("Output for f(x) = x^4 + 2x + 1 ");
            Console.WriteLine();
            Console.WriteLine(Fibonacci(-1, 0, 0.000000001));
            
            Console.Read();
        }
    }
}
