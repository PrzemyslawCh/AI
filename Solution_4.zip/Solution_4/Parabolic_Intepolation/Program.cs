﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Parabolic_Intepolation
{
    internal class Program
    {
        public static double Function(double x)
        {
            return x * x * x * x + 2 * x + 1;
        }
        static void Paraboli(double x0,double x1 , double x2,double Eps1, double Eps2)
        {
            double xd = (((x2 * x2 - x0 * x0) * Function(x1)) +
                ((x1 * x1 - x2*x2) * Function(x0)) +
                ((x0 * x0 - x1 * x1) * Function(x2))) /
                 (((x2 - x0) * Function(x1)) +
                ((x1 - x2) * Function(x0)) +
                ((x0 - x1) * Function(x2)));
          
            xd /= 2;
            
            while (Math.Abs(x0 - xd) > Eps1)
            {
                if (Math.Abs(((x2 - x0) * Function(x1)) +
                     ((x1 - x2) * Function(x0)) +
                     ((x0 - x1) * Function(x2))) <= Eps2)
                {
                    Console.WriteLine("X0: " + x0 + " Y0: " + Function(x0));
                }
                xd = (((x2 * x2 - x0 * x0) * Function(x1)) +
                ((x1 * x1 - x2 * x2) * Function(x0)) +
                ((x0 * x0 - x1 * x1) * Function(x2))) /
                 (((x2 - x0) * Function(x1)) +
                ((x1 - x2) * Function(x0)) +
                ((x0 - x1) * Function(x2)));
                
               
                xd /= 2;

                if (Function(x0)  < Function(xd))
                {
                    if (x0 < xd)
                    {
                        x2 = xd;

                    }
                    else
                    {
                        x1 = xd;
                    }
                }
                else if (Function(x0)  == Function(xd))
                {
                    if (x0 < xd)
                    {
                        x1 = x0;
                        x2 = xd;
                        x0 = (x1 + x2) / 2;
                    }
                    if (x0 > xd)
                    {
                        x1 = xd;
                        x2 = x0;
                        x0 = (x1 + x2) / 2;
                    }

                }
                else if(Function(x0) > Function(xd))
                { 
                    if (x0 > xd)
                    {
                        x2 = x0;
                        x0 = xd;
                    }
                    else
                    {
                        x1 = x0;
                        x0 = xd;
                    }
                }
            }

            Console.WriteLine("X0: " + x0 + " Y0: " + Function(x0));

        }
        static void Main(string[] args)
        {

            Console.WriteLine("Solution for x1 = -1, x0 = -0.7 , x2 = 0.6 " );
            Console.WriteLine();
            Console.WriteLine("F(x) = x^4 + 2x + 1 ");
            Console.WriteLine();
            Paraboli(-0.7, -1,0.6, 0.00001, 0.0001);
            Console.Read();
        }
    }
}
