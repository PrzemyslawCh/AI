﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Bisection_Search
{
    //DONE 
    internal class Program
    {
        
        //Function given in ex1
        public static double Function(double x)
        {
            return x * x * x * x + 2 * x + 1;
        }
        //Derivative of first Function
        public static double Derivative(double x)
        {
            return 4 * x * x * x + 2;
        }
        //Function given in ex2
        public static double Funtion2(double x)
        {
           return Math.Pow(Math.E,-x) + Math.Pow(x,2);
        }
        //Derivative of second Function
        public static double Derivative2(double x)
        {
            return 2 * x - Math.Pow(Math.E, -x);
        }
        public static double Bisection(double a, double b , double E)
        {
            double c =  (a + b) / 2;           

            while ((b-a) > E) 
            {
                if (Derivative(c) < 0)
                {
                    a = c;
                    c = (a + b) / 2;
                }
                else if (Derivative(c) > 0)
                {
                    b = c;
                    c = (a + b) / 2;
                }
                
            }
            return c;
        }
        public static double Bisection2(double a, double b, double E)
        {
            double c = (a + b) / 2;

            while ((b - a) > E)
            {
                if (Derivative2(c) < 0)
                {
                    a = c;
                    c = (a + b) / 2;
                }
                else if (Derivative2(c) > 0)
                {
                    b = c;
                    c = (a + b) / 2;
                }

            }
            return c;
        }




        static void Main(string[] args)
        {


            Console.WriteLine("Output for f(x) = x^4 + 2x + 1 when x : (-1, 0)  : ");
            Console.WriteLine(Bisection(-1, 0, 0.000001));
            Console.WriteLine("Output for f(x) = e^(-x) + x^2 when x : (0, 1) : ");
            Console.WriteLine(Bisection2(0, 1, 0.00001));

            Console.Read();
        }
    }
}
