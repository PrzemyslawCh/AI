﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Direct_Search
{
    //MAYBEDONE
    internal class Program
    {
        public static double Function(double x)
        {
            return x * x * x * x + 2 * x + 1;
        }
        public static double Funtion2(double x)
        {
            return Math.Pow(Math.E, -x) + Math.Pow(x, 2);
        }

        public static string Direct(double x0, double delta)
        {
                     
            double x1 = x0 + delta;
            double x2 = x1 + delta;


            while (Function(x1) <= Function(x0))
            {
                delta = 2 * delta;
                x2 = x1 + delta;
                if (Function(x2) >= Function(x1))
                {
                    return "[" + x0 + ", " + x2 + "]";
                }
                else
                {
                    x0 = x1;
                    x1 = x2;
                }

            }

            delta = 2 * delta;
            x2 = x0 - delta;

            while (Function(x0) <= Function(x2))
            {
                if (Function(x0) <= Function(x2))
                {
                    return "[" + x2 + ", " + x1 + "]";
                }
                else
                {
                    x1 = x0;
                    x0 = x2;                  
                }

            }

            return "";

            
        }
        static void Main(string[] args)
        {
            Console.WriteLine("Output for f(x) = x^4 + 2x + 1 x0 = -1 delta = 0.0000001 ");
            Console.WriteLine();
            Console.WriteLine(Direct(-1,0.0000001));
            Console.ReadKey();
        }
    }
}
