﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Golden_Section
{
    //DONES
    //To run program if your in visual just click start or F5 ON keyboard 
    internal class Program
    {
        public static double Golden2(double a, double b, double Eps)
        {
            double Ta = ((1 + Math.Sqrt(5)) / 2) - 1;

            double x2 = a + Ta * (b - a);

            double x1 = a + (1 - Ta) * (b - a);
         
            while (Math.Abs(b - a) > Eps)
            {
                if (Function2(x1) < Function2(x2))
                {
                    b = x2;
                    x2 = x1;
                    x1 = a + (1 - Ta) * (b - a);

                }
                else if (Function2(x1) == Function2(x2))
                {
                    a = x1;
                    b = x2;
                    x2 = a + Ta * (b - a);

                }
                else
                {
                    a = x1;
                    x1 = x2;
                    x2 = a + Ta * (b - a);

                }
            }
            return (a + b) / 2;
        }
        public static double Golden(double a, double b, double Eps)
        {
            double Ta = ((1 + Math.Sqrt(5)) / 2) - 1;

            double x2 = a + Ta * (b - a);

            double x1 = a + (1 - Ta) * (b - a);

            while (Math.Abs(b - a) > Eps)
            {
                if (Function(x1) < Function(x2))
                {
                    b = x2;
                    x2 = x1;
                    x1 = a + (1 - Ta) * (b - a);

                }
                else if (Function(x1) == Function(x2))
                {
                    a = x1;
                    b = x2;
                    x2 = a + Ta * (b - a);

                }
                else
                {
                    a = x1;
                    x1 = x2;
                    x2 = a + Ta * (b - a);

                }
            }
            return (a + b) / 2;
        }
        public static double Function(double x)
        {
            return x * x * x * x + 2 * x + 1;
        }
        public static double Function2(double x)
        {
            return Math.Pow(Math.E, -x) + Math.Pow(x, 2);
        }
        static void Main(string[] args)
        {

            Console.WriteLine("Output for f(x) = x^4 + 2x + 1 ");
            Console.WriteLine(Golden(-1, 0, 0.0000000001));

            Console.WriteLine("Output fot f(x) = e^(-x) + x^2 ");
            Console.WriteLine(Golden2(0, 1, 0.0001));

            Console.Read();
        }
    }
}
